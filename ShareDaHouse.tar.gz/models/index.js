module.exports = {
  House: require("./House"),
  Room: require("./Room"),
  Booking: require("./Booking")
};


